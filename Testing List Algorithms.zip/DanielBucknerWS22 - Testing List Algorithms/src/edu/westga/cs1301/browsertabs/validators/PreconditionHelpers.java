package edu.westga.cs1301.browsertabs.validators;

public class PreconditionHelpers {
	/**
	 * Validates that an object is not null.
	 * 
	 * @param obj any object
	 * @param msg error message if the value is null
	 * @throws IllegalArgumentException if obj is null, using msg as the error message
	 */
	public static void validateNotNull(Object obj, String msg) {
		if (obj == null) {
			throw new IllegalArgumentException(msg);
		}
	}
	
	/**
	 * Validates that a string is not blank.
	 * 
	 * @param text any String
	 * @param msg error message if the text is blank
	 * @throws IllegalArgumentException if text is blank, using msg as the error message
	 */
	public static void validateNotBlank(String text, String msg) {
		if (text.isBlank()) {
			throw new IllegalArgumentException(msg);
		}
	}
}
