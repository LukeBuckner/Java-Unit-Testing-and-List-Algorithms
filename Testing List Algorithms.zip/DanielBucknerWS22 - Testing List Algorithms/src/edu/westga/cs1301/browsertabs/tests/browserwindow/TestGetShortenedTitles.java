package edu.westga.cs1301.browsertabs.tests.browserwindow;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.browsertabs.model.BrowserTab;
import edu.westga.cs1301.browsertabs.model.BrowserWindow;

public class TestGetShortenedTitles {

	@Test
	public void testWhenNoTabs() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		
		// Act
		ArrayList<String> shortTitles = browser.getShortenedTitles();
		
		// Assert
		assertTrue(shortTitles.isEmpty());
	}

	@Test
	public void testWhenOneTab() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("West Georgia", "westga.edu/library");
		browser.add(tab0);
		
		// Act
		ArrayList<String> shortTitles = browser.getShortenedTitles();
		
		// Assert
		assertEquals(1, shortTitles.size());
		assertEquals("Wes", shortTitles.get(0));
	}
	
	@Test
	public void testWhenSeveralTabs() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("UWG", "westga.edu/library");
		browser.add(tab0);
		
		BrowserTab tab1 = new BrowserTab("Facebook", "facebook.com");
		browser.add(tab1);
		
		BrowserTab tab2 = new BrowserTab("reddit", "reddit.com/r/retrobattlestations");
		browser.add(tab2);
		
		// Act
		ArrayList<String> shortTitles = browser.getShortenedTitles();
		
		// Assert
		assertEquals(3, shortTitles.size());
		assertEquals("UWG", shortTitles.get(0));
		assertEquals("Fac", shortTitles.get(1));
		assertEquals("red", shortTitles.get(2));
	}
}
