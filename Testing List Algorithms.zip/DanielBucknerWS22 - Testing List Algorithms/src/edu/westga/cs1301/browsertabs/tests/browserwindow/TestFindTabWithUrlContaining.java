package edu.westga.cs1301.browsertabs.tests.browserwindow;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.browsertabs.model.BrowserTab;
import edu.westga.cs1301.browsertabs.model.BrowserWindow;

public class TestFindTabWithUrlContaining {

	@Test
	public void testWhenNoTabs() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		
		// Act
		BrowserTab actualTab = browser.findTabWithUrlContaining("westga.edu");
		
		// Assert
		assertNull(actualTab);
	}

	@Test
	public void testWhenOneTabThatMatches() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("tab0", "westga.edu/library");
		browser.add(tab0);
		
		// Act
		BrowserTab actualTab = browser.findTabWithUrlContaining("westga.edu");
		
		// Assert
		assertEquals(tab0, actualTab);
	}
	
	@Test
	public void testWhenOneTabThatDoesNotMatch() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("tab0", "westga.edu/library");
		browser.add(tab0);
		
		// Act
		BrowserTab actualTab = browser.findTabWithUrlContaining("example.com");
		
		// Assert
		assertNull(actualTab);
	}
	
	@Test
	public void testWhenFirstTabMatches() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("UWG", "westga.edu/library");
		browser.add(tab0);
		
		BrowserTab tab1 = new BrowserTab("Facebook", "facebook.com");
		browser.add(tab1);
		
		BrowserTab tab2 = new BrowserTab("reddit", "reddit.com/r/retrobattlestations");
		browser.add(tab2);
		
		// Act
		BrowserTab actualTab = browser.findTabWithUrlContaining("westga.edu");
		
		// Assert
		assertEquals(tab0, actualTab);
	}
	
	@Test
	public void testWhenLastTabMatches() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("UWG", "westga.edu/library");
		browser.add(tab0);
		
		BrowserTab tab1 = new BrowserTab("Facebook", "facebook.com");
		browser.add(tab1);
		
		BrowserTab tab2 = new BrowserTab("reddit", "reddit.com/r/retrobattlestations");
		browser.add(tab2);
		
		// Act
		BrowserTab actualTab = browser.findTabWithUrlContaining("reddit.com");
		
		// Assert
		assertEquals(tab2, actualTab);
	}
	
	@Test
	public void testWhenMiddleTabMatches() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("UWG", "westga.edu/library");
		browser.add(tab0);
		
		BrowserTab tab1 = new BrowserTab("Facebook", "facebook.com");
		browser.add(tab1);
		
		BrowserTab tab2 = new BrowserTab("reddit", "reddit.com/r/retrobattlestations");
		browser.add(tab2);
		
		// Act
		BrowserTab actualTab = browser.findTabWithUrlContaining("face");
		
		// Assert
		assertEquals(tab1, actualTab);
	}
	
	@Test
	public void testWhenNoTabsMatch() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("UWG", "westga.edu/library");
		browser.add(tab0);
		
		BrowserTab tab1 = new BrowserTab("Facebook", "facebook.com");
		browser.add(tab1);
		
		BrowserTab tab2 = new BrowserTab("reddit", "reddit.com/r/retrobattlestations");
		browser.add(tab2);
		
		// Act
		BrowserTab actualTab = browser.findTabWithUrlContaining("example.com");
		
		// Assert
		assertNull(actualTab);
	}
}
