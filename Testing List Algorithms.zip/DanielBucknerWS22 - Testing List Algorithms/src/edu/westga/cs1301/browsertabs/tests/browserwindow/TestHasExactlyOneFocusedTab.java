package edu.westga.cs1301.browsertabs.tests.browserwindow;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.browsertabs.model.BrowserTab;
import edu.westga.cs1301.browsertabs.model.BrowserWindow;

public class TestHasExactlyOneFocusedTab {

	@Test
	public void testWhenNoTabs() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		
		// Act
		boolean actual = browser.hasExactlyOneFocusedTab();
		
		// Assert
		assertFalse(actual);
	}

	
	@Test
	public void testWhenOnlyOneTabAndItIsFocused() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("West Georgia", "westga.edu/library");
		tab0.setFocused();
		browser.add(tab0);
		
		// Act
		boolean actual = browser.hasExactlyOneFocusedTab();
		
		// Assert
		assertTrue(actual);
	}
	
	@Test
	public void testWhenOnlyOneTabAndItIsNotFocused() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("West Georgia", "westga.edu/library");
		browser.add(tab0);
		
		// Act
		boolean actual = browser.hasExactlyOneFocusedTab();
		
		// Assert
		assertFalse(actual);
	}
	
	@Test
	public void testWhenManyTabsAndOneIsFocused() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("UWG", "westga.edu/library");
		browser.add(tab0);
		
		BrowserTab tab1 = new BrowserTab("Facebook", "facebook.com");
		browser.add(tab1);
		tab1.setFocused();
		
		BrowserTab tab2 = new BrowserTab("reddit", "reddit.com/r/retrobattlestations");
		browser.add(tab2);
		
		// Act
		boolean actual = browser.hasExactlyOneFocusedTab();
		
		// Assert
		assertTrue(actual);
	}
	
	@Test
	public void testWhenManyTabsAndNoneAreFocused() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("UWG", "westga.edu/library");
		browser.add(tab0);
		
		BrowserTab tab1 = new BrowserTab("Facebook", "facebook.com");
		browser.add(tab1);
		
		BrowserTab tab2 = new BrowserTab("reddit", "reddit.com/r/retrobattlestations");
		browser.add(tab2);
		
		// Act
		boolean actual = browser.hasExactlyOneFocusedTab();
		
		// Assert
		assertFalse(actual);
	}
	
	@Test
	public void testWhenManyTabsAndMultipleAreFocused() {
		// Arrange
		BrowserWindow browser = new BrowserWindow();
		BrowserTab tab0 = new BrowserTab("UWG", "westga.edu/library");
		browser.add(tab0);
		tab0.setFocused();
		
		BrowserTab tab1 = new BrowserTab("Facebook", "facebook.com");
		browser.add(tab1);
		
		BrowserTab tab2 = new BrowserTab("reddit", "reddit.com/r/retrobattlestations");
		browser.add(tab2);
		tab2.setFocused();
		
		// Act
		boolean actual = browser.hasExactlyOneFocusedTab();
		
		// Assert
		assertFalse(actual);
	}
}
