package edu.westga.cs1301.browsertabs.model;

import java.util.ArrayList;

import edu.westga.cs1301.browsertabs.validators.PreconditionHelpers;

/**
 * Represents a browser window that contains
 * some number of browswer tabs.
 * 
 * @author lewisb
 *
 */
public class BrowserWindow {
	private ArrayList<BrowserTab> tabs;
	
	/**
	 * Creates a new BrowserWindow with no tabs.
	 */
	public BrowserWindow() {
		this.tabs = new ArrayList<BrowserTab>();
	}
	
	/**
	 * Adds a tab to the BrowserWindow
	 * 
	 * @precondition tab != null
	 * @postcondition the window contains the tab
	 * 
	 * @param tab the new tab to add
	 */
	public void add(BrowserTab tab) {
		PreconditionHelpers.validateNotNull(tab, "tab can't be null");
		this.tabs.add(tab);
	}
	
	/**
	 * Finds the first browser tab with a URL containing the given text.
	 * 
	 * @precondition text != null && !text.isBlank();
	 * @param text the search text
	 * @return the first matching tab, or null if no match found
	 */
	public BrowserTab findTabWithUrlContaining(String text) {
		PreconditionHelpers.validateNotNull(text, "text can't be null");
		PreconditionHelpers.validateNotBlank(text, "text can't be blank");
		
		for (BrowserTab tab : this.tabs) {
			if (tab.getUrl().contains(text)) {
				return tab;
			}
		}
		
		return null;
	}
	
	/**
	 * Returns a list of strings which are the titles of the
	 * tabs truncated to 3 characters. This is necessary as the number
	 * of browser tabs gets so big that their full titles can't
	 * be displayed.
	 * 
	 * @precondition none
	 * @postcondition none
	 *
	 * @return a list of the shortened titles
	 */
	public ArrayList<String> getShortenedTitles() {
		ArrayList<String> results = new ArrayList<String>();
		
		for (BrowserTab tab : this.tabs) {
			String shortTitle = tab.getTitle().substring(0, 3);
			results.add(shortTitle);
		}
		
		return results;
	}
	
	/**
	 * Only one BrowserTab at a time can be focused. This
	 * method checks to make sure that is the case.
	 * 
	 * @return true if exactly one browser tab is focused; false otherwise
	 * (including false if the window has no tabs)
	 */
	public boolean hasExactlyOneFocusedTab() {
		int count = 0;
		for (BrowserTab tab : this.tabs) {
			if (tab.getHasTheFocus()) {
				count++;
			}
		}
		return (count == 1);
	}
}
