package edu.westga.cs1301.browsertabs.model;

import java.awt.Color;

import edu.westga.cs1301.browsertabs.validators.PreconditionHelpers;

/**
 * Represents information concerning a tab
 * on a web browser: its title, its icon
 * (for simplicity represented by a single color instead
 * of an actual picture), and a URL.
 * 
 * @author lewisb
 *
 */
public class BrowserTab {
	private String title;
	private String url;
	private boolean hasTheFocus;
	
	/**
	 * Creates a new tab that does not have focus.
	 * 
	 * @precondition title != null && !title.isBlank() && 
	 * 	url != null
	 * @postcondition getTitle()==title && getHasTheFocus()==false && getUrl()==url
	 * 
	 * @param title the title to display on the tab
	 * @param url the URL to display in the tab
	 */
	public BrowserTab(String title, String url) {
		PreconditionHelpers.validateNotNull(title, "title can't be null");
		PreconditionHelpers.validateNotBlank(title, "title can't be blank");
		PreconditionHelpers.validateNotNull(url, "url can't be null");
		
		this.title = title;
		this.hasTheFocus = false;
		this.url = url;
	}

	/**
	 * Gets the title
	 * @return the title
	 */
	public String getTitle() {
		return this.title;
	}
	
	/**
	 * Gets the URL
	 * 
	 * @return the URL
	 */
	public String getUrl() {
		return this.url;
	}
	
	/**
	 * Indicates whether or not this tab has the focus
	 * (i.e., is currently displayed). Only one tab
	 * at a time should have the focus.
	 * 
	 * @return true if focused, false otherwise
	 */
	public boolean getHasTheFocus() {
		return this.hasTheFocus;
	}
	
	/**
	 * Gives this tab focus.
	 */
	public void setFocused() {
		this.hasTheFocus = true;
	}
	
	/**
	 * Un-focuses this tab
	 */
	public void setNotFocused() {
		this.hasTheFocus = false;
	}
}
