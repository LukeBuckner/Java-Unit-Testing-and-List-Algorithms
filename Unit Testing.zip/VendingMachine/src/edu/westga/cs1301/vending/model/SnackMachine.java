package edu.westga.cs1301.vending.model;

/**
 * Simulates a snack machine with a few items
 * that can be purchased
 * 
 * @author lewisb
 *
 */
public class SnackMachine {
	private double gumPrice;
	private double candyPrice;
	private double chipsPrice;
	
	private int gumInOrder;
	private int candyInOrder;
	private int chipsInOrder;
	
	private double totalSales;
	private double paymentTendered;
	
	
	public SnackMachine (double getGumPrice, double getCandyPrice, double getChipsPrice) {
		changePrices(getGumPrice, getCandyPrice, getChipsPrice);
		resetOrder();
		resetMachine();
		
	}
	
	
	public double completeOrder() {
		double orderTotal = (gumInOrder * gumPrice) + (candyInOrder * candyPrice) + (chipsInOrder * chipsPrice);
		double change = paymentTendered - orderTotal;
		totalSales = totalSales + orderTotal;
		resetOrder();
		return change;
		
	}
	
	public double getOrderTotal() {
		this.totalSales = this.totalSales + (gumInOrder * gumPrice) + (candyInOrder * candyPrice) + (chipsInOrder * chipsPrice);
		return totalSales;
		
	}
	
	
	public int addGumToOrder(int gum) {
		this.gumInOrder = this.gumInOrder + gum;
		return gumInOrder;
		
	}
	
	public int addCandyToOrder(int candy) {
		this.candyInOrder = this.candyInOrder + candy;
		return candyInOrder;
		
	}
	
	public int addChipsToOrder(int chips) {
	this.chipsInOrder = this.chipsInOrder + chips;
	return chipsInOrder;
	
	}

		
	public double putInMoney(double money) {
		this.paymentTendered = this.paymentTendered + money;
		return paymentTendered;
		
	}
	
	private void resetMachine() {
		this.totalSales = (this.gumInOrder + this.candyInOrder + this.chipsInOrder);
	}



	private void resetOrder() {
		this.gumInOrder = 0;
		this.candyInOrder = 0;
		this.chipsInOrder = 0;
		this.paymentTendered = 0;
	}



	public void changePrices(double getGumPrice, double getCandyPrice, double getChipsPrice) {
		this.gumPrice = getGumPrice;
		this.candyPrice = getCandyPrice;
		this.chipsPrice = getChipsPrice;
	}
	
	
	
	public double getGumPrice() {
		return this.gumPrice;
	}

	public double getCandyPrice() {
		return this.candyPrice;
	}

	public double getChipsPrice() {
		return this.chipsPrice;
	}

	public int getGumInOrder() {
		return this.gumInOrder;
	}

	public int getCandyInOrder() {
		return this.candyInOrder;
	}

	public int getChipsInOrder() {
		return this.chipsInOrder;
	}

	public double getTotalSales() {
		return this.totalSales;
	}

	public double getPaymentTendered() {
		return this.paymentTendered;
	}



}
